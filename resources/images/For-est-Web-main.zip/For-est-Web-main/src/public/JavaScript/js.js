function changeText() {
    document.getElementById('usuario_cambio').innerHTML + "Texto cambiao";
}

    